﻿namespace BudgetBook.Data
{
    public class Entry
    {
        public decimal Amount { get; set; }
        public string? Description { get; set; }
    }
}
